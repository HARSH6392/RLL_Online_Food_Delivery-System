import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgotpassword.component.html',
  styleUrls: ['./forgotpassword.component.css']
})
export class ForgotPasswordComponent {
  constructor(private http: HttpClient) {}

  ResetButton() {
    // Implement your API call to send a reset link to the provided email address
    // Example using HttpClient:
  
        alert('Reset link Send Successfull.');
      }

    }
